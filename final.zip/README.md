# WebDev7
WebDev coursework

## Working on the project

 - Use VS Code
 - Use Git

### Extentions

 - HTML CSS Support
 - Live Server
 - Prettier
 - vscode-pdf

### Using Live Server

After instalation, in the lower right conner, when inside a html file, you will see a Go Live button. Press the button and see the page open in the browser. Refreshes every save.

### Using Prettier

Install and go into settings (ctrl+) and search for default formatter. Set formater to Prettier. Before pushing code to github press (Shift Alt F) and format the file.